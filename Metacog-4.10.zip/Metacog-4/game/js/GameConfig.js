/*exported buildGameConfig */
"use strict";

function buildGameConfig(/*mainScope*/) {
  return {
    fadeOut: 500, // fade out final between trials
    totalTrials: 2,
    trial_000: {
      deck: {
        cards: [[0, 20],
                [8, 0],
                [20, 8]],
        rotations: [[90, 0],
                    [0, 180],
                    [0, 315]],
        training: "a",
      }
    },
    trial_001: {
      deck: {
        cards: [[3, 5],
                  [5, 3]],
        rotations: [[90, 0],
                    [0, 180]],
        training: "a",
      }
    },
    preload: {
      correctSound: "sounds/correct.mp3",
      wrongSound: "sounds/wrong.mp3",
      background: "img/background.png",
      getOutButton: "img/button.png",
      backSideCards: "img/cards/backSideCards.png",
      frontSideCards: {
        extension: ".png",
        prefix: "img/cards/frontSides/",
        indexes: [0, 41],
      },
    },
    instructions: {
      limit: 5,
      content: ["titulo", "texto"],
      titulo: {
        type: "text",
        code: "GT.instructions.title"
      },
      texto: {
        type: "text",
        code: "GT.instructions.text"
      }
    }
  };
}