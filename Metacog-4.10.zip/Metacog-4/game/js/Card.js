/*global createjs, Shape, setProperties, console*/
"use strict";

function Card(parameters) {
  this.initialize(parameters);
}

Card.prototype = new createjs.Container();
Card.prototype.ContainerInitialize = Card.prototype.initialize;
Card.prototype.ContainerTick = Card.prototype._tick;

Card.prototype.initialize = function (parameters) {
  var bound;

  this.ContainerInitialize();
  setProperties(this, parameters);

  // this function allow the circles to have animations;
  function circleAnimation(parameters, time, interpolation) {
    return createjs.Tween.get(this)
      .to(parameters, time, interpolation);
  }

  // front and back sides creations
  this.frontSide = new Shape(parameters.frontSide);
  this.backSide = new Shape(parameters.backSide);

  bound = this.frontSide.getBounds();

  this.frontSide.regX = bound.width * 0.5;
  this.frontSide.regY = bound.height * 0.5;

  bound = this.backSide.getBounds();

  this.backSide.regX = bound.width * 0.5;
  this.backSide.regY = bound.height * 0.5;

  this.backSide.scaleX = 0;

  this.addChild(this.frontSide);
  this.addChild(this.backSide);

  bound = this.getBounds();

  // wrong circle creation
  this.wrongCircle = new createjs.Shape();
  this.wrongCircle.graphics.beginFill(parameters.wrongColor)
    .drawCircle(bound.width * 0.5, bound.height * 0.5, bound.width * 0.5 + 10);

  this.wrongCircle.regX = bound.width  * 0.5;
  this.wrongCircle.regY = bound.height  * 0.5;

  this.wrongCircle.animation = circleAnimation;

  // correct circle cretion
  this.correctCircle = new createjs.Shape();
  this.correctCircle.graphics.beginFill(parameters.correctColor)
    .drawCircle(bound.width * 0.5, bound.height * 0.5, bound.width * 0.5 + 10);

  this.correctCircle.regX = bound.width  * 0.5;
  this.correctCircle.regY = bound.height  * 0.5;

  this.correctCircle.animation = circleAnimation;

  // selected circle cretion
  this.selectedCircle = new createjs.Shape();
  this.selectedCircle.graphics.beginFill(parameters.selectedColor)
    .drawCircle(bound.width * 0.5, bound.height * 0.5, bound.width * 0.5 + 10);

  this.selectedCircle.regX = bound.width  * 0.5;
  this.selectedCircle.regY = bound.height  * 0.5;

  this.selectedCircle.animation = circleAnimation;

};

Card.prototype.animation = function (parameters, time, interpolation) {
  return createjs.Tween.get(this)
      .to(parameters, time, interpolation);
};

Card.prototype.getInCircle = function (circle, time) {

  this[circle].scaleX = 0;
  this[circle].scaleY = 0;
  this.addChildAt(this[circle], 0);

  return this[circle].animation({scaleX: 1, scaleY: 1}, time);
};

Card.prototype.getOutCircle = function (circle, time) {

  return this[circle].animation({scaleX: 0, scaleY: 0}, time)
    .call(this.removeChild.bind(this, this[circle]));
};

Card.prototype.turn = function (parameters) {

  function circlesIn() {
    if (this.wrongCircle.scaleY !== 0) {
      this.wrongCircle.animation({scaleX: 1}, parameters.secondHalfTime, createjs.Ease.bounceOut);
    }
    if (this.correctCircle.scaleY !== 0) {
      this.correctCircle.animation({scaleX: 1}, parameters.secondHalfTime, createjs.Ease.bounceOut);
    }
    if (this.selectedCircle.scaleY !== 0) {
      this.selectedCircle.animation({scaleX: 1}, parameters.secondHalfTime, createjs.Ease.bounceOut);
    }
  }

  function frontIn() {
    circlesIn.call(this);
    return this.frontSide.animation({scaleX: 1}, parameters.secondHalfTime, createjs.Ease.bounceOut);
  }

  function backIn() {
    circlesIn.call(this);
    return this.backSide.animation({scaleX: 1}, parameters.secondHalfTime, createjs.Ease.bounceOut);
  }

  // circles animation
  this.correctCircle.animation({scaleX: 0}, parameters.firstHalfTime);
  this.wrongCircle.animation({scaleX: 0}, parameters.firstHalfTime);
  this.selectedCircle.animation({scaleX: 0}, parameters.firstHalfTime);

  // turnin
  if (this.frontSide.scaleX === 1) {
    return this.frontSide.animation({scaleX: 0}, parameters.firstHalfTime)
      .call(backIn.bind(this));
  }

  return this.backSide.animation({scaleX: 0}, parameters.firstHalfTime)
    .call(frontIn.bind(this));
};

Card.prototype.correctAnswerA = function (parameters) {

  this.mouseEnabled = false;

  function turnAndGetOut() {

    this.turn(parameters)
      .call(this.getOutCircle.bind(this, "correctCircle", 0));
  }

  this.getInCircle("correctCircle", 0);
  return this.animation({}, 0)
    .wait(parameters.waitingTime)
    .call(turnAndGetOut.bind(this));
};

Card.prototype.wrongAnswerA = function (parameters) {

  return this.getInCircle("wrongCircle", 0)
    .wait(parameters.waitingTime)
    .call(this.getOutCircle.bind(this, "wrongCircle", 0));
};

Card.prototype.correctAnswerB = function (parameters) {

  this.mouseEnabled = false;
  createjs.Sound.play(this.correctSound);

  function turnAndGetOut() {
    this.turn(parameters)
      .call(this.getOutCircle.bind(this, "correctCircle", 0));
  }

  this.getInCircle("correctCircle", 0);
  return this.animation({rotation: 0}, parameters.rotationTime, createjs.Ease.bounceOut)
    .wait(parameters.waitingTime)
    .call(turnAndGetOut.bind(this));
};

Card.prototype.wrongAnswerB = function (parameters) {

  var originalRotation = this.rotation;
  createjs.Sound.play(this.wrongSound);

  function turnAndGetOut() {
    this.animation({rotation: originalRotation}, parameters.rotationTime, createjs.Ease.bounceOut)
      .call(this.getOutCircle.bind(this, "wrongCircle", 0));
  }

  this.getInCircle("wrongCircle", 0);
  return this.animation({rotation: 0}, parameters.rotationTime, createjs.Ease.bounceOut)
    .wait(parameters.waitingTime)
    .call(turnAndGetOut.bind(this));
};

Card.prototype.correctAnswerC = function (parameters) {

  this.mouseEnabled = false;
  return this.turn(parameters);
};

Card.prototype.wrongAnswerC = function (parameters) {

  return this.getInCircle("wrongCircle", 0)
    .wait(parameters.waitingTime)
    .call(this.getOutCircle.bind(this, "wrongCircle", 0));
};
