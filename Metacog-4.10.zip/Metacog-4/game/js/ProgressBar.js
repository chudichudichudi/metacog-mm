/*global createjs, setProperties*/
"use strict";

function ProgressBar(parameters) {
  this.initialize(parameters);
}

ProgressBar.prototype = new createjs.Container();
ProgressBar.prototype.containerInitialize = ProgressBar.prototype.initialize;
ProgressBar.prototype.containerTick = ProgressBar.prototype._tick;

ProgressBar.prototype.initialize = function (parameters) {
  this.containerInitialize();
  setProperties(this, parameters);

  this.totalHeight = parameters.height;

  // frame
  this.frame = new createjs.Shape();
  this.frame.graphics.beginStroke("#808080");
  this.frame.graphics.setStrokeStyle(1);
  this.frame.graphics.drawRect(0, 0, parameters.width, parameters.height);
  this.frame.shadow = new createjs.Shadow("#000000", 0, 0, 10);

  this.rectangle = new createjs.Shape();
  this.rectangle.graphics.beginLinearGradientFill(["rgba(0,0,0,1)", "rgba(150,150,150,0)"], [0, 0.9], 0, parameters.height * 0.5, parameters.width * 0.75, parameters.height * 0.5).drawRect(0, 0, parameters.width, parameters.height);
  this.rectangle.graphics.beginLinearGradientFill(["rgba(0,0,0,1)", "rgba(150,150,150,0)"], [0, 0.9], parameters.width, parameters.height * 0.5, parameters.width * 0.25, parameters.height * 0.5).drawRect(0, 0, parameters.width, parameters.height);
  this.rectangle.shadow = new createjs.Shadow("#000000", 0, 0, 10);

  this.addChild(this.frame);
  this.addChild(this.rectangle);

  this.countDown = createjs.Tween.get(this.rectangle, {paused: true})
    .to({scaleY: 0, y: this.totalHeight}, this.time, createjs.Ease.out)
    .call(parameters.callback);
};

ProgressBar.prototype.fadeOut = function (time) {

  return createjs.Tween.get(this)
    .to({alpha: 0}, time, createjs.Ease.out);

};