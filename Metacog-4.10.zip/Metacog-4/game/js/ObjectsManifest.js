/*global SpriteButton, CardsDeck, Text, Shape, ProgressBar */
/*global MateMarote, stageWidth, stageHeight */
/*exported buildObjectManifest, objectConstructors */
"use strict";

function buildObjectManifest(mainScope) {

  return {
    background: {
      constructor: Shape,
      zIndex: 0,
      global: true,
      parameters: {
        src: "background",
        x: 0,
        y: 0
      }
    },
    finalText: {
      constructor: Text,
      zIndex: 2,
      global: true,
      parameters: {
        text: MateMarote.getLocaleString("GT.gameOver"),
        font: "bold 36px Arial",
        color: "rgba(0,0,0,0.75)",
        regCentered: true,
        alpha: 0,
        scaleX: 1.5,
        scaleY: 1.5,
        x: stageWidth * 0.5,
        y: stageHeight * 0.35
      }
    },
    getOutButton: {
      constructor: SpriteButton,
      zIndex: 2,
      addToStage: true,
      global: true,
      parameters: {
        onClick: MateMarote.returnToGameflow,
        src: "getOutButton",
        width: 200,
        height: 70,
        textParameters: {
          text: MateMarote.getLocaleString("GT.gameFlow"),
          font: "bold 36px Arial",
          color: "rgba(0,0,0,0.75)",
          regCentered: true,
          scaleX: 0.8,
          scaleY: 0.8,
        },
        x: stageWidth * 0.5,
        y: stageHeight * 0.5,
        regX: 100,
        regY: 35,
        mouseEnabled: false,
        alpha: 0,
      }
    },
    progressBar: {
      constructor: ProgressBar,
      zIndex: 2,
      parameters: {
        width: 30,
        height: 400,
        callback: mainScope.timeFinished,
        time: 10000,
        regX: 30,
        regY: 400,
        y: stageHeight - stageHeight * 0.05,
        x: stageWidth - stageWidth * 0.05
      }
    },
    deck: {
      constructor: CardsDeck,
      dependencies: ["progressBar"],
      zIndex: 2,
      parameters: {
        regCentered: true,
        correctSound: "correctSound",
        wrongSound: "wrongSound",
        correctColor: "#00FF00",
        wrongColor: "#FF0000",
        selectedColor: "#0000FF",
        rotations: null,
        cards: null,
        distance: 350,
        disableMouse: false,
        x: stageWidth * 0.5,
        y: stageHeight * 0.5,
        scaleX: 0.5,
        scaleY: 0.5,
        cardScaleX: 0.8,
        cardScaleY: 0.8,
        finish: mainScope.finishTrial,
        animationParameters: {
          firstHalfTime: 150, // turn animations
          secondHalfTime: 300, // turn animations
          waitingTime: 2000, // specified in the game instruction like 2sec.
          rotationTime: 500
        }
      }
    }
  };
}

var objectConstructors = {
  Shape: Shape
};