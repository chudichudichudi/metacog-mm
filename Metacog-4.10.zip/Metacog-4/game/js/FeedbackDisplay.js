/*global createjs, newCenteredBitmap, stageWidth, stageHeight, Preloader, setProperties*/
"use strict";

function newCenteredBitmap(preloadedKey) {
  var bmp = new createjs.Bitmap(Preloader.get(preloadedKey));
  bmp.regX = bmp.image.width / 2;
  bmp.regY = bmp.image.height / 2;
  return bmp;
}

function FeedbackDisplay(parameters) {
  this.initialize(parameters);
}

FeedbackDisplay.prototype = new createjs.Container();
FeedbackDisplay.prototype.containerInitialize = FeedbackDisplay.prototype.initialize;

FeedbackDisplay.prototype.initialize = function (parameters) {

  this.containerInitialize();
  setProperties(this, parameters);

  this.checkAsset = newCenteredBitmap("feedbackPositive");
  this.failAsset = newCenteredBitmap("feedbackNegative");
  this.checkAsset.x = this.failAsset.x = stageWidth / 2;
  this.checkAsset.y = this.failAsset.y = stageHeight / 2;
  this.failAsset.alpha = this.checkAsset.alpha = 0.5;
  this.failAsset.visible = false;
  this.checkAsset.visible = false;

  this.addChild(this.failAsset, this.checkAsset);
};

FeedbackDisplay.prototype.show = function (isPositiveFeedback) {
  this.visible = this.activated;
  this.checkAsset.visible = isPositiveFeedback;
  this.failAsset.visible = !isPositiveFeedback;
  setTimeout(
    function () {
      this.visible = false;
      this.callback();
    }.bind(this),
    this.feedbackTime
  );
};