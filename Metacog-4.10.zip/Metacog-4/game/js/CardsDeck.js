/*global createjs, setProperties, engine, Metrics */
/*global Card, STATUS */
"use strict";

function CardsDeck(parameters) {
  this.initialize(parameters);
}

CardsDeck.prototype = new createjs.Container();
CardsDeck.prototype.containerInitialize = CardsDeck.prototype.initialize;
CardsDeck.prototype.containerTick = CardsDeck.prototype._tick;

CardsDeck.prototype.initialize = function (parameters) {
  this.containerInitialize();
  var i, j, newCards, cardParameters, bound, height, width;

  this.disableMouse = false;
  setProperties(this, parameters);

  this.cardsPosition = [];

  height = parameters.cards.length;
  for (i = 0; i < height; ++i) {
    width = parameters.cards[i].length;

    for (j = 0; j < width; ++j) {

      cardParameters = {
        scaleX: parameters.cardScaleX,
        scaleY: parameters.cardScaleY,
        correctColor: parameters.correctColor,
        wrongColor: parameters.wrongColor,
        selectedColor: parameters.selectedColor,
        frontSide: {src: "frontSideCards" + parameters.cards[i][j]},
        backSide: {src: "backSideCards"},
        name: "card_" + j + "_" + i,
        correctSound: parameters.correctSound,
        wrongSound: parameters.wrongSound,
        rotation: parameters.rotations[i][j],
        match: parameters.cards[i][j],
        x: j * parameters.distance,
        y: i * parameters.distance
      };
      newCards = new Card(cardParameters);

      newCards.addEventListener("click", this.cardSelected.bind(this, newCards));
      this.addChild(newCards);
      this.cardsPosition.push({position: "(" + j + ", " + i + ")", name: "frontSideCards" + parameters.cards[i][j]});
    }
  }

  if (parameters.hasOwnProperty("regCentered")) {
    if (parameters.regCentered) {
      bound = this.getBounds();

      this.regX = bound.x + (bound.width * 0.5);
      this.regY = bound.y + (bound.height * 0.5);
    }
  }

  this.correctAnimations = {
    a: "correctAnswerA",
    b: "correctAnswerB",
    c: "correctAnswerC"
  };

  this.wrongAnimations = {
    a: "wrongAnswerA",
    b: "wrongAnswerB",
    c: "wrongAnswerC"
  };

  width = (height > 0) ? parameters.cards[0].length : 0;
  this.progressBar = engine.trialObjects.progressBar;
  this.leftCards = height * width;
  this.selectedCard = {
    empty: true
  };
};

CardsDeck.prototype.cardSelected = function (card) {
  this.mouseEnabled = false;
  card.mouseEnabled = false;
  var imTheLast = false;
  var lastSelectedCard;

  Metrics.addData("events", "card selection", "selected card: " + card.name);
  Metrics.saveMetrics();

  function mayFinish(letItFinish) {
    if (letItFinish) {
      this.finish(STATUS.WON);
    } else {
      this.mouseEnabled = true;
    }
  }

  function enableMouse(cardToEnable1, cardToEnable2) {
    cardToEnable1.mouseEnabled = true;
    cardToEnable2.mouseEnabled = true;
    this.mouseEnabled = true;
  }

  if (this.selectedCard.empty) {

    Metrics.addData("trialResults", "card match", "there isn't selected cards to match with");
    Metrics.saveMetrics();

    this.selectedCard.card = card;
    this.selectedCard.empty = false;
    card.getInCircle("selectedCircle", 0);
    card.mouseEnabled = false;
    this.mouseEnabled = true;
  } else {
    lastSelectedCard = this.selectedCard.card;
    this.selectedCard.empty = true;
    lastSelectedCard.getOutCircle("selectedCircle", 0);

    if (lastSelectedCard.match === card.match) {

      Metrics.addData("events", "card match", card.name + " and " + lastSelectedCard.name);
      Metrics.saveMetrics();

      this.leftCards -= 2;
      if (this.leftCards === 0) {
        this.progressBar.countDown.setPaused(true);
        imTheLast = true;
      }
      this.mouseEnabled = !(this.disableMouse);
      lastSelectedCard[this.correctAnimations[this.training]](this.animationParameters);
      card[this.correctAnimations[this.training]](this.animationParameters);
      setTimeout(mayFinish.bind(this, imTheLast), this.animationParameters.waitingTime + this.animationParameters.firstHalfTime + this.animationParameters.secondHalfTime + 250);

    } else {

      Metrics.addData("events", "card match", "wrong match betwen " + card.name + " and " + lastSelectedCard.name);
      Metrics.addData("events", "card selection", "deselected cards: " + card.name + " and " + lastSelectedCard.name);
      Metrics.saveMetrics();

      this.mouseEnabled = !(this.disableMouse);
      lastSelectedCard[this.wrongAnimations[this.training]](this.animationParameters);
      card[this.wrongAnimations[this.training]](this.animationParameters);
      setTimeout(enableMouse.bind(this, card, lastSelectedCard), this.animationParameters.waitingTime + this.animationParameters.firstHalfTime + this.animationParameters.secondHalfTime + 250);
    }
  }
};

CardsDeck.prototype.fadeOut = function (time) {
  return createjs.Tween.get(this)
    .to({alpha: 0}, time);
};