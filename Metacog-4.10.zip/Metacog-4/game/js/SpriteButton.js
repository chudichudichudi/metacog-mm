/*global SpriteButton, Text */
/*global createjs, setProperties, Preloader */
"use strict";

function SpriteButton(parameters) {
  this.initialize(parameters);
}
//Inheritance from Container
SpriteButton.prototype = new createjs.Container();
SpriteButton.prototype.containerInitialize = SpriteButton.prototype.initialize;
SpriteButton.prototype.containerTick = SpriteButton.prototype._tick;

SpriteButton.prototype.initialize = function (parameters) {

  this.containerInitialize();
  setProperties(this, parameters);

  this.imageData = {
    images: [Preloader.get(parameters.src)],
    frames: {width: parameters.width, height: parameters.height},
    animations: { normal: [0], pressed: [1], over: [2] }
  };
  this.spriteSheet = new createjs.SpriteSheet(this.imageData);
  this.animation = new createjs.Sprite(this.spriteSheet, "normal");
  this.addChild(this.animation);


  this.addEventListener("mousedown", function (event) {
    event.currentTarget.animation.gotoAndStop("pressed");
  });
  this.addEventListener("pressup", function (event) {
    event.currentTarget.animation.gotoAndStop("over");
  });
  this.addEventListener("mouseover", function (event) {
    event.currentTarget.animation.gotoAndStop("over");
  });
  this.addEventListener("mouseout", function (event) {
    event.currentTarget.animation.gotoAndStop("normal");
  });
  this.addEventListener("click", parameters.onClick);

  parameters.textParameters.x = parameters.textParameters.x || (this.getBounds().x + this.getBounds().width * 0.5);
  parameters.textParameters.y = parameters.textParameters.y || (this.getBounds().y + this.getBounds().height * 0.5);
  this.text = new Text(parameters.textParameters);
  this.addChild(this.text);

};

SpriteButton.prototype.TweenAnimation = function (parameters, time, interpolation) {
  return createjs.Tween.get(this)
    .to(parameters, time, interpolation);
};

SpriteButton.prototype._tick = this.containerTick;