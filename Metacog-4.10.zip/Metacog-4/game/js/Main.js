"use strict";
/*global gameInit, buildObjects, buildGameConfig, Engine, buildObjectManifest, buildGlobalObjects, globalGameObject, addAllToSubStage, MateMarote, Progress, createjs, Metrics  */
/*global stage, subStage, STATUS */
/*global Progress, playTrial, $, console */

var engine;

(function () {
  var objectsManifest;
  var gameData;
  var myCanvas = $("#stageCanvas").get(0);

  ///////////////////////////////////////////////////////////////
  /////////////////// **** Functions **** ///////////////////////
  ///////////////////////////////////////////////////////////////

  function finishGame() {

    Progress.gameEnded();

    engine.globalObjects.finalText.animation({alpha: 1}, 1000, createjs.Ease.bounceInOut);
    engine.globalObjects.getOutButton.TweenAnimation({alpha: 1, mouseEnabled: true}, 1000, createjs.Ease.bounceInOut);

    Metrics.addData("progress", "game point", "game finished");
    Metrics.saveMetrics();
    MateMarote.synchronize();
  }

  function nextStep(status) {

    engine.nextTrial(status);


    if (engine.trialConfig !== null) {
      playTrial();
    } else {
      finishGame();
    }
  }

  function finishTrial(status) {
    function partB() {

      subStage.removeChild(engine.trialObjects.progressBar);
      subStage.removeChild(engine.trialObjects.deck);
      stage.update();

      if (status === STATUS.WON) {

        Metrics.addData("progress", "trial point", "trial finished");
        Metrics.addData("trialResult", "result", "correctly matched");

      } else if (status === STATUS.LOST) {

        Metrics.addData("progress", "trial point", "trial finished");
        Metrics.addData("trialResult", "result", "erroneously matched");

      } else if (status === STATUS.NOT_ANSWERED) {

        Metrics.addData("progress", "trial point", "trial finished");
        Metrics.addData("trialResult", "result", "non answered");

      }
      nextStep(status);
      Metrics.saveMetrics();
    }

    engine.trialObjects.progressBar.fadeOut(gameData.fadeOut);
    engine.trialObjects.deck.fadeOut(gameData.fadeOut).call(partB);

    Metrics.addData("trialEvents", "deck", "deck out");
    Metrics.addData("trialEvents", "progressBar", "progressBar out");
    Metrics.saveMetrics();
  }

  function playTrial() {
    var totalNumCards, cardPosition, cardName, i;
    Progress.trialPlay();

    engine.buildTrialObjects();
    engine.addAllToSubStage();
    stage.update();

    // saving metrics
    totalNumCards = engine.trialObjects.deck.cardsPosition.length;
    Metrics.addData("progress", "trial point", "start trial");
    Metrics.addData("trialConfig", "total cards", totalNumCards);
    for (i = 0; i < totalNumCards; ++i) {
      cardPosition = engine.trialObjects.deck.cardsPosition[i].position;
      cardName = engine.trialObjects.deck.cardsPosition[i].name;
      Metrics.addData("trialConfig", "card position", cardPosition);
      Metrics.addData("trialConfig", "card name", cardName);
    }
    Metrics.saveMetrics();

    engine.trialObjects.progressBar.countDown.setPaused(false);
  }

  function startGame() {
    var currentStatus;
    createjs.Ticker.setFPS(20);
    createjs.Ticker.addEventListener("tick", stage);
    stage.enableMouseOver(10);

    Metrics.addData("progress", "game point", "start game");
    Metrics.saveMetrics();

    currentStatus = (Progress.progress.gameData.notFirstTime === true) ? STATUS.RESUME_GAME : STATUS.DEPARTURE_POINT;
    engine.nextTrial(currentStatus);

    engine.buildGlobalObjects();
    engine.addAllToSubStage(true);

    if (engine.trialConfig === null) {
      finishGame();
    } else {
      playTrial();
    }
  }

  ///////////////////////////////////////////////////////////////
  //////////////// **** End of Functions **** ///////////////////
  ///////////////////////////////////////////////////////////////



  //////////////////////////////////////////////////////////////
  //////////// **** Game developer functions **** //////////////
  //////////////////////////////////////////////////////////////


  Progress.nextTrial = function (status) {
    var result = "trial_";

    switch (status) {

    case STATUS.DEPARTURE_POINT:

      result += "000";
      Progress.progress.gameData.currentNumberTrial = 0;
      Progress.progress.gameData.notFirstTime       = true;
      Progress.progress.gameData.current_trial      = result;
      break;

    case STATUS.RESUME_GAME:

      if (Progress.progress.gameData.currentNumberTrial < gameData.totalTrials) {
        result = Progress.progress.gameData.current_trial;
      } else {
        result += "000";
        Progress.progress.gameData.currentNumberTrial = 0;
        Progress.progress.gameData.current_trial      = result;
      }
      break;

    default:

      ++Progress.progress.gameData.currentNumberTrial;
      if (Progress.progress.gameData.currentNumberTrial < gameData.totalTrials) {

        result += ("000" + Progress.progress.gameData.currentNumberTrial).slice(-3);
      } else {

        result = null;
      }
      Progress.progress.gameData.current_trial = result;
    }

    MateMarote.synchronize();
    return result;
  };

  function timeFinished() {

    Metrics.addData("events", "time", "time over");
    Metrics.saveMetrics();

    engine.trialObjects.progressBar.countDown.setPaused(false);
    finishTrial(STATUS.NOT_ANSWERED);
  }

  //////////////////////////////////////////////////////////////
  ////////// **** End game developer functions **** ////////////
  //////////////////////////////////////////////////////////////

  var mainScope = {
    myCanvas: myCanvas,
    startGame: startGame,
    finishTrial: finishTrial,
    nextStep: nextStep,
    playTrial: playTrial,
    finishGame: finishGame,
    timeFinished: timeFinished,
  };


  engine          = new Engine(buildGameConfig(), startGame, false);
  objectsManifest = buildObjectManifest(mainScope);
  engine.addObjects(objectsManifest);
  gameData        = MateMarote.gameData.stepConfig;
}());