/*exported buildGameConfig */
"use strict";

function buildGameConfig(/*mainScope*/) {
  return {};
}