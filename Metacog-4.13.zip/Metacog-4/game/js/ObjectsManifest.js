/*global SpriteButton, CardsDeck, Text, Shape, ProgressBar */
/*global MateMarote, stageWidth, stageHeight */
/*exported buildObjectManifest, objectConstructors */
"use strict";

function buildObjectManifest(mainScope) {
  return {};
}